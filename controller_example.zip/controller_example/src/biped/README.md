# biped

它的整体结构是一目了然的。`others`中堆放一些未分类整理的代码；
`sans.ttf`是用来显示joystick窗口中的字的。
